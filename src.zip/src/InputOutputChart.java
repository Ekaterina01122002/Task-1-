import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

// элемент блок-схемы ввод-вывод (параллелограмм)
public class InputOutputChart extends ChartElement {

    public InputOutputChart(Color color, double x, double y, double w, double h, String text) {
        super(color, x, y, w, h, text);
    }

    @Override
    void draw(GraphicsContext gc) {
        gc.setStroke(color);
        gc.fillText(text, x + w / 10, y + h / 2 + 5);

        gc.beginPath();
        gc.moveTo(x, y);
        gc.lineTo(x + w, y);
        gc.lineTo(x + 0.6 * w, y + h);
        gc.lineTo(x - 0.4 * w, y + h);
        gc.closePath();
        gc.stroke();
    }
}
