import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

public class Ellipse extends Shape {

    // эллипс задается полуосями a и b
    protected double a, b;

    public Ellipse(Color color, double x, double y, double a, double b) {
        super(color, x, y);
        this.a = a;
        this.b = b;
    }

    @Override
    double area() {
        return Math.PI * a * b;
    }

    @Override
    void draw(GraphicsContext gc) {
        gc.setStroke(color);
        gc.strokeOval(x, y, a * 2, b * 2);
    }

    @Override
    public String toString() {
        return "Ellipse color is " + super.color + " and area is " + area();
    }

    public double getA() {
        return a;
    }

    public void setA(double a) {
        this.a = a;
    }

    public double getB() {
        return b;
    }

    public void setB(double b) {
        this.b = b;
    }
}
