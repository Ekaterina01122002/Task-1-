import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

// элемент "ИЛИ"
public class OrElement extends LogicElement {
    public OrElement(Color color, double x, double y, double length, double width) {
        super(color, x, y, length, width);
    }

    @Override
    void draw(GraphicsContext gc) {
        super.draw(gc);
        gc.fillText("1", xCenter - 5, y + width / 5);
        gc.fillText("A", x - length / 2 - 10, y + width * 0.2 + 5);
        gc.strokeLine(x - length / 2, y + width * 0.2, x, y + width * 0.2);
        gc.fillText("B", x - length / 2 - 10, y + width * 0.8 + 5);
        gc.strokeLine(x - length / 2, y + width * 0.8, x, y + width * 0.8);
    }

    @Override
    public String toString() {
        return super.toString() + ", OR";
    }
}

