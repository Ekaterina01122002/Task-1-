import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

// крыльцо домика (несколько прямоугольников, имитирующих ступеньки)
public class Porch extends Shape {
    // задаем только ширину самой широкой ступеньки
    // высотру вычислим
    protected double w, h;

    public Porch(Color color, double x, double y, double w) {
        super(color, x, y);
        this.w = w;
        this.h = 0.1 * w;
    }

    @Override
    double area() {
        return w * h + 0.8 * w * h + 0.5 * w * h;
    }

    @Override
    void draw(GraphicsContext gc) {
        gc.setStroke(color);
        gc.strokeRect(x, y, w, h);
        gc.strokeRect(x + 0.1 * w, y + h, w * 0.8, h);
        gc.strokeRect(x + 0.25 * w, y + 2 * h, w * 0.5, h);
    }

    @Override
    public String toString() {
        return "Porch color is " + super.color + " and area is " + area();
    }

    public double getW() {
        return w;
    }

    public void setW(double w) {
        this.w = w;
    }

    public double getH() {
        return h;
    }
}
