import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

// скругленный прямоугольник
public class RoundedRectangle extends Rectangle {

    public RoundedRectangle(Color color, double x, double y, double length, double width) {
        super(color, x, y, length, width);
    }

    @Override
    void draw(GraphicsContext gc) {
        gc.setStroke(color);
        gc.strokeRoundRect(x, y, length, width, 0.3 * length, 0.3 * width);
    }

    @Override
    public String toString() {
        return "Rounded " + super.toString();
    }
}
