import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

// забор
public class Fence extends Shape {
    // забор это несколько прямоугольников и несколько треугольников
    // характеризуется высотой прямоугольника и их количеством
    protected double h, w, triangleH;
    protected int n;

    public Fence(Color color, double x, double y, double h, int n) {
        super(color, x, y);
        this.h = h;
        this.w = h * 0.1;
        this.triangleH = Math.sqrt(3) / 2 * this.w;
        this.n = n;
    }

    @Override
    double area() {
        return n * h * w + n * w * triangleH / 2;
    }

    @Override
    void draw(GraphicsContext gc) {
        gc.setStroke(color);
        for (int i = 0; i < n; i++) {
            gc.strokeRect(x + i * w, y, w, h);
            gc.strokeLine(x + i * w + w / 2, y - triangleH, x + i * w, y);
            gc.strokeLine(x + i * w + w / 2, y - triangleH, x + + i * w + w, y);
            gc.strokeLine(x + i * w, y,x + + i * w + w, y);
        }
    }

    @Override
    public String toString() {
        return "Fence color is " + super.color + " and area is " + area();
    }

    public double getH() {
        return h;
    }

    public void setH(double h) {
        this.h = h;
        this.w = h * 0.1;
        this.triangleH = Math.sqrt(3) / 2 * this.w;
    }

    public double getW() {
        return w;
    }

    public double getTriangleH() {
        return triangleH;
    }

    public int getN() {
        return n;
    }

    public void setN(int n) {
        this.n = n;
    }
}
