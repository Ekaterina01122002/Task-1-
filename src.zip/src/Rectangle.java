import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

// прямоугольник
public class Rectangle extends Shape {
    // прямоугольник задается длиной и шириной
    protected double length;
    protected double width;

    public Rectangle(Color color, double x, double y, double length, double width) {
        super(color, x, y);
        this.length = length;
        this.width = width;
    }

    @Override
    double area() {
        return length * width;
    }

    @Override
    void draw(GraphicsContext gc) {
        gc.setStroke(color);
        gc.strokeRect(x, y, length, width);
    }

    @Override
    public String toString() {
        return "Rectangle color is " + super.color + " and area is " + area();
    }

    public double getLength() {
        return length;
    }

    public void setLength(double length) {
        this.length = length;
    }

    public double getWidth() {
        return width;
    }

    public void setWidth(double width) {
        this.width = width;
    }
}
