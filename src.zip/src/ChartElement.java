import javafx.scene.paint.Color;

// базовый класс для элементов блок-схем
public abstract class ChartElement extends Shape {
    // характерисуется шириной, высотой и текстом внутри блока
    protected double w, h;
    protected String text;

    public ChartElement(Color color, double x, double y, double w, double h, String text) {
        super(color, x, y);
        this.h = h;
        this.w = w;
        this.text = text;
    }

    @Override
    double area() {
        return w * h;
    }

    @Override
    public String toString() {
        return "Flowchart: " + text + ", color is " + color + ", area is " + area();
    }

    public double getW() {
        return w;
    }

    public void setW(double w) {
        this.w = w;
    }

    public double getH() {
        return h;
    }

    public void setH(double h) {
        this.h = h;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
