import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

// элемент "НЕ"
public class NotElement extends LogicElement {
    public NotElement(Color color, double x, double y, double length, double width) {
        super(color, x, y, length, width);
    }

    @Override
    void draw(GraphicsContext gc) {
        super.draw(gc);
        gc.fillText("A", x - length / 2 - 10, yCenter + 5);
        gc.strokeLine(x - length / 2, yCenter, x, yCenter);
        gc.strokeOval(x + length - 2, yCenter - 2, 5, 5);
    }

    @Override
    public String toString() {
        return super.toString() + ", NOT";
    }
}
