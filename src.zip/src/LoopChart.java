import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

// элемент блок-схемы цикл (прямоугольник со скошенными углами)
public class LoopChart extends ChartElement {

    public LoopChart(Color color, double x, double y, double w, double h, String text) {
        super(color, x, y, w, h, text);
    }

    @Override
    void draw(GraphicsContext gc) {
        gc.setStroke(color);
        gc.fillText(text, x + w / 3, y + h / 2 + 5);

        gc.strokeLine(x + 0.15 * w, y, x + 0.85 * w, y);
        gc.strokeLine(x, y + h, x + w, y + h);
        gc.strokeLine(x, y + 0.3 * h, x, y + h);
        gc.strokeLine(x + w, y + 0.3 * h, x + w, y + h);
        gc.strokeLine(x + 0.15 * w, y, x, y + 0.3 * h);
        gc.strokeLine(x + 0.85 * w, y, x + w, y + 0.3 * h);
    }
}
