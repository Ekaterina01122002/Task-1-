import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

// абстрактный суперкласс
public abstract class Shape {
    protected Color color;
    protected double x, y;

    abstract double area();
    abstract void draw(GraphicsContext gc);
    public abstract String toString();
    public Shape(Color color, double x, double y) {
        this.color = color;
        this.x = x;
        this.y = y;
    }

    public void setColor(Color color) {
        this.color = color;
    }

    public void setX(double x) {
        this.x = x;
    }

    public void setY(double y) {
        this.y = y;
    }

    public Color getColor() {
        return color;
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }
}
