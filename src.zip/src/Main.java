import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.canvas.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class Main extends Application {

    // варианты фигур и соответствующие им наборы кнопок
    enum ShapeType {graph, house, chart, logic}
    Button rectButton, ellipseButton, roundedRectButton, squareButton;
    Button wallButton, windowButton, porchButton, roofButton, fenceButton;
    Button inputButton, decisionButton, loopButton, outputButton;
    Button andButton, orButton, notButton, orNotButton, andNotButton;

    // канва для рисования
    Canvas canvas;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage stage) {
        // создаем кнопки
        initAllButtons();

        // создаем канву для рисования
        canvas = new Canvas(500, 300);

        // создаем панель с кнопками
        FlowPane flowPane = new FlowPane();
        flowPane.setAlignment(Pos.CENTER);
        flowPane.setHgap(20);
        changeType(ShapeType.graph, flowPane);

        // создаем меню для выбора варианта фигур
        MenuBar menuBar = new MenuBar();
        Menu menu = new Menu("Фигуры");
        MenuItem graphItem = new MenuItem("Графический редактор");
        graphItem.setOnAction(event -> changeType(ShapeType.graph, flowPane));
        MenuItem houseItem = new MenuItem("Строим домик");
        houseItem.setOnAction(event -> changeType(ShapeType.house, flowPane));
        MenuItem chartItem = new MenuItem("Блок-схема");
        chartItem.setOnAction(event -> changeType(ShapeType.chart, flowPane));
        MenuItem logicItem = new MenuItem("Цифровая схема");
        logicItem.setOnAction(event -> changeType(ShapeType.logic, flowPane));
        menu.getItems().addAll(graphItem, houseItem, chartItem, logicItem);
        menuBar.getMenus().add(menu);

        // создаем контейнер для всех элементов интерфейса
        VBox vBox = new VBox(menuBar);
        vBox.getChildren().addAll(canvas, flowPane);

        // создаем и показываем сцену
        Scene scene = new Scene(vBox, 500, 370);
        stage.setScene(scene);
        stage.show();
    }

    // смена варианта фигур
    // очищает канву и меняет набор кнопок
    public void changeType(ShapeType type, FlowPane pane) {
        pane.getChildren().clear();
        canvas.getGraphicsContext2D().clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
        switch (type) {
            case graph -> pane.getChildren().addAll(rectButton, ellipseButton, roundedRectButton, squareButton);
            case house -> pane.getChildren().addAll(wallButton, windowButton, porchButton, roofButton, fenceButton);
            case chart -> pane.getChildren().addAll(inputButton, decisionButton, loopButton, outputButton);
            case logic -> pane.getChildren().addAll(andButton, orButton, notButton, orNotButton, andNotButton);
        }
    }

    // создание всех кнопок для всех фигур
    // каждая кнопка по нажатию вызывает функцию onClick с передачей соответствующей фигуры
    public void initAllButtons() {
        rectButton  = new Button("Прямоугольник");
        rectButton.setOnAction((event)-> onClick(new Rectangle(randColor(), 50, 50, 100, 50)));
        ellipseButton = new Button("Эллипс");
        ellipseButton.setOnAction((event)-> onClick(new Ellipse(randColor(), 250, 50, 50, 25)));
        roundedRectButton = new Button("Скругленный прямоугольник");
        roundedRectButton.setOnAction((event)-> onClick(new RoundedRectangle(randColor(), 50, 150, 100, 50)));
        squareButton = new Button("Квадрат");
        squareButton.setOnAction((event)-> onClick(new Square(randColor(), 250, 150, 100)));

        wallButton = new Button("Стена");
        wallButton.setOnAction((event)-> onClick(new Wall(randColor(), 150, 150, 100)));
        windowButton = new Button("Окно");
        windowButton.setOnAction((event)-> onClick(new Window(randColor(), 190, 190, 20)));
        porchButton = new Button("Крыльцо");
        porchButton.setOnAction((event)-> onClick(new Porch(randColor(), 140, 240, 80)));
        roofButton = new Button("Крыша");
        roofButton.setOnAction((event)-> onClick(new Roof(randColor(), 150, 64, 100)));
        fenceButton = new Button("Забор");
        fenceButton.setOnAction((event)-> onClick(new Fence(randColor(), 250, 150, 100, 10)));

        inputButton = new Button("Ввод");
        inputButton.setOnAction((event) -> onClick(new InputOutputChart(randColor(), 100, 50, 100, 50, "Ввод")));
        decisionButton = new Button("Решение");
        decisionButton.setOnAction((event) -> onClick(new DecisionChart(randColor(), 250, 50, 100, 50, "Решение")));
        loopButton = new Button("Цикл");
        loopButton.setOnAction((event) -> onClick(new LoopChart(randColor(), 250, 150, 100, 50, "Цикл")));
        outputButton = new Button("Вывод");
        outputButton.setOnAction((event) -> onClick(new InputOutputChart(randColor(), 100, 150, 100, 50, "Вывод")));

        andButton = new Button("И");
        andButton.setOnAction((event) -> onClick(new AndElement(randColor(), 70, 50, 40, 60)));
        orButton = new Button("ИЛИ");
        orButton.setOnAction((event) -> onClick(new OrElement(randColor(), 70, 150, 40, 60)));
        notButton = new Button("НЕ");
        notButton.setOnAction((event) -> onClick(new NotElement(randColor(), 400, 50, 40, 60)));
        orNotButton = new Button("ИЛИ-НЕ");
        orNotButton.setOnAction((event) -> onClick(new OrNotElement(randColor(), 250, 150, 40, 60)));
        andNotButton = new Button("И-НЕ");
        andNotButton.setOnAction((event) -> onClick(new AndNotElement(randColor(), 250, 50, 40, 60)));
    }

    // метод, вызываем при нажатии кнопок
    public void onClick(Shape shape) {
        GraphicsContext gc = canvas.getGraphicsContext2D();
        shape.draw(gc);
        System.out.println(shape);
    }

    // метод получения случайного цвета
    Color randColor() {
        return Color.color(Math.random(), Math.random(), Math.random());
    }
}
