import javafx.scene.paint.Color;

// квадрат (прямоугольник с одинаковыми длиной и шириной)
public class Square extends Rectangle {

    public Square(Color color, double x, double y, double length) {
        super(color, x, y, length, length);
    }

    @Override
    public String toString() {
        return "Square color is " + super.color + " and area is " + area();
    }
}
