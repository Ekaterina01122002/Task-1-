import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

// элемент блок-схемы решение (ромб)
public class DecisionChart extends ChartElement {

    public DecisionChart(Color color, double x, double y, double w, double h, String text) {
        super(color, x, y, w, h, text);
    }

    @Override
    void draw(GraphicsContext gc) {
        gc.setStroke(color);
        gc.fillText(text, x + w / 4, y + h / 2 + 5);

        gc.strokeLine(x + w / 2, y, x, y + h / 2);
        gc.strokeLine(x + w / 2, y, x + w, y + h / 2);
        gc.strokeLine(x + w / 2, y + h, x, y + h / 2);
        gc.strokeLine(x + w / 2, y + h, x + w, y + h / 2);
    }
}
