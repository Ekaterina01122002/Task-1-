import javafx.scene.paint.Color;

// стена домика (является квадратом)
public class Wall extends Square {
    public Wall(Color color, double x, double y, double a) {
        super(color, x, y, a);
    }

    public String toString() {
        return "Wall color is " + super.color + " and area is " + area();
    }
}
