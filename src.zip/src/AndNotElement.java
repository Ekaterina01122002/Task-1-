import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

// элемент И-НЕ
public class AndNotElement extends AndElement{
    public AndNotElement(Color color, double x, double y, double length, double width) {
        super(color, x, y, length, width);
    }

    @Override
    void draw(GraphicsContext gc) {
        super.draw(gc);
        gc.strokeOval(x + length - 2, yCenter - 2, 5, 5);
    }

    @Override
    public String toString() {
        return super.toString() + "-NOT";
    }
}
