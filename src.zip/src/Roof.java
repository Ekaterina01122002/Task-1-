import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

// крыша домика (правильный треугольник)
public class Roof extends Shape {
    // треугольник задаем длиной стороны
    // высоту вычисляем
    protected double a, h;

    public Roof(Color color, double x, double y, double a) {
        super(color, x, y);
        this.a = a;
        this.h = a * Math.sqrt(3) / 2;
    }

    @Override
    double area() {
        return a * h / 2;
    }

    @Override
    void draw(GraphicsContext gc) {
        gc.setStroke(color);
        gc.strokeLine(x + a / 2, y, x, y + h);
        gc.strokeLine(x + a / 2, y, x + a, y + h);
        gc.strokeLine(x, y + h, x + a, y + h);
    }

    @Override
    public String toString() {
        return "Roof color is " + super.color + " and area is " + area();
    }

    public double getSide() {
        return a;
    }

    public void setSide(double a) {
        this.a = a;
    }
}
