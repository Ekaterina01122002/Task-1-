import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

// базовый класс для логических элементов
public class LogicElement extends Rectangle {
    // для удобства вычисляем координаты центра прямоугольника
    protected double xCenter, yCenter;

    public LogicElement(Color color, double x, double y, double length, double width) {
        super(color, x, y, length, width);
        xCenter = x + length / 2;
        yCenter = y + width / 2;
    }

    @Override
    void draw(GraphicsContext gc) {
        // общее для всех элементов: прямоугольник и выход
        super.draw(gc);
        gc.setFill(color);
        gc.fillText("Y", x + 1.5 * length, yCenter + 5);
        gc.strokeLine(x + length, yCenter, x + 1.5 * length, yCenter);
    }

    @Override
    public String toString() {
        return "Logic element, color is " + color + ", area is " + area();
    }
}
