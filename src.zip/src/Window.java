import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

// окно домика (является квадратом, к которому добавим линии створок)
public class Window extends Square {
    public Window(Color color, double x, double y, double a) {
        super(color, x, y, a);
    }

    @Override
    void draw(GraphicsContext gc) {
        super.draw(gc);
        gc.strokeLine(x, y + width / 2, x + length, y + width / 2);
        gc.strokeLine(x + length / 2, y, x + length / 2, y + width);
    }

    public String toString() {
        return "Window color is " + super.color + " and area is " + area();
    }
}
